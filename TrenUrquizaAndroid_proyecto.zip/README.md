# Tren Urquiza para Android — proyecto inicial

Proyecto nativo Android (Kotlin + Jetpack Compose) para consultar horarios de la Línea Urquiza.

## Funciones incluidas en este prototipo
- Interfaz móvil inicial.
- Selector manual de estaciones.
- Solicitud de permiso de ubicación.
- Comprobación automática del sitio oficial con WorkManager cada 30 días.
- Botón para intentar actualizar manualmente.
- Descarga del PDF enlazado desde la página oficial de Metrovías y extracción de texto.
- Conserva los datos locales si falla la descarga.

## Importante: todavía no es una APK final
Este proyecto es un esqueleto funcional de desarrollo, no una versión lista para publicar ni instalar como producto terminado. El parser de tablas todavía debe validarse contra el PDF oficial vigente para reconstruir correctamente todas las salidas por estación, sentido y tipo de día. Hasta entonces la pantalla deja el horario como pendiente, en lugar de inventar horas.

La detección GPS requiere completar y verificar las coordenadas oficiales de las estaciones y asociarlas a la estación más cercana. La lista de estaciones incluida es provisional y debe revisarse (eliminar cualquier marcador provisional) antes de distribuir.

## Abrir y compilar
1. Instalar Android Studio estable con Android SDK 35.
2. Abrir esta carpeta como proyecto.
3. Esperar la sincronización de Gradle.
4. Ejecutar en un teléfono Android o usar Build > Build APK(s).

## Fuente oficial
https://metrovias.com.ar/index.php/horarios-del-servicio-linea-urquiza/

## Política de actualización
- Al abrir, puede usarse el botón “Actualizar PDF”.
- Worker periódico conectado cada 30 días (Android puede retrasarlo por batería).
- El enlace PDF se descubre desde la página oficial, no queda fijado a un archivo versionado.
