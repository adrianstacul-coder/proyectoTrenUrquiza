package ar.com.trenurquiza

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF172D48)
private val Orange = Color(0xFFE56A19)
private val stationNames = listOf(
    "Federico Lacroze", "Artigas", "Arata", "Agronomía", "Talar", "線", 
    "Villa Lynch", "Fernández Moreno", "Lourdes", "Tropezón", "José María Bosch",
    "Martín Coronado", "Pablo Podestá", "Jorge Newbery", "Rubén Darío",
    "Ejército de los Andes", "Loma Hermosa", "Del Libertador", "Sargento Barrufaldi",
    "Capitán Lozano", "Campo de Mayo", "Teniente Agneta", "Sargento Cabral", "General Lemos"
)

class MainActivity : ComponentActivity() {
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PdfScheduleUpdater.scheduleMonthly(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Orange, secondary = Navy)) {
                TrainScreen(
                    onLocate = { requestLocation() },
                    onUpdate = { lifecycleScope.launch { PdfScheduleUpdater.updateNow(this@MainActivity) } }
                )
            }
        }
    }
    private fun requestLocation() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            return
        }
        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { loc ->
            if (loc != null) {
                // Coordinates are passed to nearest-station matching once the official station-coordinate table is verified.
                getSharedPreferences("train", MODE_PRIVATE).edit()
                    .putString("last_location", "${loc.latitude},${loc.longitude}").apply()
        } }
    }
}

@Composable
private fun TrainScreen(onLocate: () -> Unit, onUpdate: () -> Unit) {
    var station by remember { mutableStateOf(stationNames.first()) }
    var direction by remember { mutableStateOf("A General Lemos") }
    var expanded by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Todavía no se verificó el PDF oficial en este dispositivo.") }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) { now = LocalDateTime.now(); kotlinx.coroutines.delay(1000) }
    }
    val clock = now.format(DateTimeFormatter.ofPattern("HH:mm:ss"))
    val nextTrain = "—:—"
    val remaining = "Horario pendiente de importar"
    Column(Modifier.fillMaxSize().background(Color(0xFFF3F6FA)).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(48.dp).background(Orange, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text("T", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Column(Modifier.weight(1f)) {
                Text("Próximo Tren", color = Navy, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Línea Urquiza · Metrovías", color = Color.Gray)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("HORA ACTUAL", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(clock, color = Navy, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Divider()
                Text("TU ESTACIÓN", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(station, modifier = Modifier.weight(1f)); Text("⌄")
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 360.dp)) {
                        stationNames.forEach { name -> DropdownMenuItem(text = { Text(name) }, onClick = { station = name; expanded = false }) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onLocate, modifier = Modifier.weight(1f)) { Text("Usar GPS") }
                    OutlinedButton(onClick = onUpdate, modifier = Modifier.weight(1f)) { Text("Actualizar PDF") }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("PRÓXIMO TREN", color = Color(0xFFCFD8E3), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(nextTrain, color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Black)
                Text(remaining, color = Color(0xFFFFD9C2), fontSize = 16.sp)
                Text("Sentido", color = Color(0xFFCFD8E3))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = direction == "A General Lemos", onClick = { direction = "A General Lemos" }, label = { Text("A Gral. Lemos") })
                    FilterChip(selected = direction == "A Federico Lacroze", onClick = { direction = "A Federico Lacroze" }, label = { Text("A F. Lacroze") })
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Horarios oficiales", color = Navy, fontWeight = FontWeight.Bold)
                Text(message, color = Color.DarkGray)
                Text("Actualización automática: cada 30 días. Los horarios se mostrarán como programados, no como seguimiento GPS en vivo.", color = Color.Gray, fontSize = 12.sp)
                Text("Fuente: metrovias.com.ar", color = Orange, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
