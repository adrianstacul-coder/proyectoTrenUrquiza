package ar.com.trenurquiza

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * Monthly source refresh. The official page is discovered each run instead of pinning
 * a PDF URL that can become obsolete. The downloaded PDF is cached only after a
 * successful download and non-empty text extraction.
 *
 * NOTE: timetable PDF layouts can change. This starter stores extracted text; parsing
 * it into station-by-station departures must be validated against the current PDF.
 */
object PdfScheduleUpdater {
    private const val PAGE = "https://metrovias.com.ar/index.php/horarios-del-servicio-linea-urquiza/"
    private const val UNIQUE_WORK = "urquiza-monthly-pdf-check"

    fun scheduleMonthly(context: Context) {
        val request = PeriodicWorkRequestBuilder<MonthlyPdfWorker>(30, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(UNIQUE_WORK, ExistingPeriodicWorkPolicy.KEEP, request)
    }

    suspend fun updateNow(context: Context) = withContext(Dispatchers.IO) {
        downloadAndExtract(context)
    }

    internal fun downloadAndExtract(context: Context): String {
        PDFBoxResourceLoader.init(context)
        val page = Jsoup.connect(PAGE).userAgent("TrenUrquizaAndroid/0.1").timeout(25000).get()
        val pdfUrl = page.select("a[href$=.pdf], a[href*=.pdf]").mapNotNull { it.absUrl("href").takeIf(String::isNotBlank) }
            .firstOrNull { it.contains("Horarios-Urquiza", ignoreCase = true) }
            ?: throw IllegalStateException("No se encontró el enlace al PDF de horarios en la página oficial.")
        val prefs = context.getSharedPreferences("train", Context.MODE_PRIVATE)
        val knownUrl = prefs.getString("pdf_url", null)
        if (knownUrl == pdfUrl && prefs.getString("pdf_text", "").orEmpty().isNotBlank()) {
            prefs.edit().putString("last_check", System.currentTimeMillis().toString()).apply()
            return "El PDF no cambió. Se conservan los horarios guardados."
        }
        val connection = URL(pdfUrl).openConnection() as HttpURLConnection
        connection.connectTimeout = 20000
        connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "TrenUrquizaAndroid/0.1")
        val bytes = connection.inputStream.use { it.readBytes() }
        require(bytes.size > 1000) { "El PDF descargado parece incompleto." }
        val temp = java.io.File(context.cacheDir, "urquiza-timetable.pdf")
        temp.writeBytes(bytes)
        val text = PDDocument.load(temp).use { PDFTextStripper().getText(it) }
        require(text.length > 200) { "No se pudo extraer texto útil del PDF." }
        prefs.edit()
            .putString("pdf_url", pdfUrl)
            .putString("pdf_text", text)
            .putString("last_check", System.currentTimeMillis().toString())
            .putString("last_success", System.currentTimeMillis().toString())
            .apply()
        "PDF descargado y texto extraído. Falta validar el parser de tablas contra el formato vigente."
    }
}

class MonthlyPdfWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        withContext(Dispatchers.IO) { PdfScheduleUpdater.downloadAndExtract(applicationContext) }
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }
}
